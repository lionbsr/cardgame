package com.example.demo2;

public class Ucak extends HavaAraclari {
    public Ucak() {
        super(20); // Dayanıklılık: 20
    }

    @Override
    public String getAltSinif() {
        return "Uçak"; // Alt sınıf adı
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getKaraVurusAvantaji() {
        return 10;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}
