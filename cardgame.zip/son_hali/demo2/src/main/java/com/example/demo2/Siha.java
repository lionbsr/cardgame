package com.example.demo2;



public class Siha extends HavaAraclari {
    public Siha() {
        super(15); // Dayanıklılık: 15
    }

    @Override
    public String getAltSinif() {
        return "Siha";
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getKaraVurusAvantaji() {
        return 10;
    }

    public int getDenizVurusAvantaji() {
        return 10;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}

