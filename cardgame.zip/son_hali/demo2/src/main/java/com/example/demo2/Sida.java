package com.example.demo2;



public class Sida extends DenizAraclari {
    public Sida() {
        super(15); // Dayanıklılık: 15
    }

    @Override
    public String getAltSinif() {
        return "Sida";
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getHavaVurusAvantaji() {
        return 10;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}
