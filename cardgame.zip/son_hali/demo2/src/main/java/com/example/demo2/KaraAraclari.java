package com.example.demo2;



public abstract class KaraAraclari extends SavasAraclari {
    public KaraAraclari(int dayaniklilik) {
        super(dayaniklilik);
    }

    @Override
    public String getSinif() {
        return "Kara";
    }

    public abstract String getAltSinif(); // Alt sınıf adı (Obüs, KFS)
    public abstract int getDenizVurusAvantaji(); // Deniz saldırısına avantaj
}
