package com.example.demo2;



public abstract class HavaAraclari extends SavasAraclari {
    public HavaAraclari(int dayaniklilik) {
        super(dayaniklilik);
    }

    @Override
    public String getSinif() {
        return "Hava";
    }

    public abstract String getAltSinif(); // Alt sınıf adı (Uçak, Siha)
    public abstract int getKaraVurusAvantaji(); // Kara saldırısına avantaj
}

