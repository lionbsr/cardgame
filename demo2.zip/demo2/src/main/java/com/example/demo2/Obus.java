package com.example.demo2;

public class Obus extends KaraAraclari {
    public Obus() {
        super(20); // Dayanıklılık: 20
    }

    @Override
    public String getAltSinif() {
        return "Obüs"; // Alt sınıf adı
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getDenizVurusAvantaji() {
        return 5;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}
