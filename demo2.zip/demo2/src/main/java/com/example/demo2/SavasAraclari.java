package com.example.demo2;

public abstract class SavasAraclari {
    private int seviyePuani = 0; // Varsayılan başlangıç puanı
    private int dayaniklilik;

    public SavasAraclari(int dayaniklilik) {
        this.dayaniklilik = dayaniklilik;
    }

    public abstract String getSinif(); // Kara, Hava veya Deniz
    public abstract int getVurus();   // Saldırı gücü

    public abstract String getAltSinif(); // Bu metod eklendi (alt sınıf adı için)

    public int getDayaniklilik() {
        return dayaniklilik;
    }

    public void setDayaniklilik(int dayaniklilik) {
        this.dayaniklilik = dayaniklilik;
    }

    public int getSeviyePuani() {
        return seviyePuani;
    }

    public void setSeviyePuani(int seviyePuani) {
        this.seviyePuani = seviyePuani;
    }

    public void KartPuaniGoster() {
        System.out.println("Dayanıklılık: " + dayaniklilik + ", Seviye Puanı: " + seviyePuani);
    }

    public abstract void DurumGuncelle(int hasar); // Saldırı sonrası güncelleme
}
