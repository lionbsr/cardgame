package com.example.demo2;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Oyuncu {
    private int oyuncuID;
    private String oyuncuAdi;
    private int skor;
    private List<SavasAraclari> kartListesi;

    // Yeni eklenen değişken
    private List<SavasAraclari> secilmisKartlar;

    // Parametreli constructor
    public Oyuncu(int oyuncuID, String oyuncuAdi, int skor) {
        this.oyuncuID = oyuncuID;
        this.oyuncuAdi = oyuncuAdi;
        this.skor = skor;
        this.kartListesi = new ArrayList<>();
        this.secilmisKartlar = new ArrayList<>(); // Yeni eklenen satır
    }

    // Parametresiz constructor (Bilgisayar için varsayılan)
    public Oyuncu() {
        this(0, "Bilgisayar", 0);
    }

    // Getter ve Setter metodları
    public int getOyuncuID() {
        return oyuncuID;
    }

    public void setOyuncuID(int oyuncuID) {
        this.oyuncuID = oyuncuID;
    }

    public String getOyuncuAdi() {
        return oyuncuAdi;
    }

    public void setOyuncuAdi(String oyuncuAdi) {
        this.oyuncuAdi = oyuncuAdi;
    }

    public int getSkor() {
        return skor;
    }

    public void setSkor(int skor) {
        this.skor = skor;
    }

    public List<SavasAraclari> getKartListesi() {
        return kartListesi;
    }

    public void setKartListesi(List<SavasAraclari> kartListesi) {
        this.kartListesi = kartListesi;
    }

    // Yeni eklenen Getter ve Setter metodları
    public List<SavasAraclari> getSecilmisKartlar() {
        return secilmisKartlar;
    }

    public void setSecilmisKartlar(List<SavasAraclari> secilmisKartlar) {
        this.secilmisKartlar = secilmisKartlar;
    }

    public void SkorGoster() {
        System.out.println(oyuncuAdi + " Skor: " + skor);
    }

    public SavasAraclari kartSec(boolean rastgeleSecim) {
        if (kartListesi.isEmpty()) {
            System.out.println("Kart listesi boş!");
            return null;
        }

        if (rastgeleSecim) {
            // Bilgisayar rastgele seçim yapar, ancak daha önce seçilmiş kartları kontrol eder
            List<SavasAraclari> secilmemisKartlar = new ArrayList<>(kartListesi);
            secilmemisKartlar.removeAll(secilmisKartlar);

            // Eğer seçilmemiş kart kalmadıysa, seçilmiş kartları sıfırlarız
            if (secilmemisKartlar.isEmpty()) {
                secilmisKartlar.clear();
                secilmemisKartlar = new ArrayList<>(kartListesi);
            }

            Random random = new Random();
            SavasAraclari secilenKart = secilmemisKartlar.get(random.nextInt(secilmemisKartlar.size()));
            secilmisKartlar.add(secilenKart);
            return secilenKart;

        } else {
            // Kullanıcı seçim yapar (interaktif)
            System.out.println("Kullanıcı, aşağıdaki kartlardan birini seçiniz:");
            for (int i = 0; i < kartListesi.size(); i++) {
                System.out.println((i + 1) + ". " + kartListesi.get(i).getAltSinif());
            }

            int index = -1;
            while (index < 1 || index > kartListesi.size()) {
                try {
                    System.out.print("Seçiminizi giriniz (1-" + kartListesi.size() + "): ");
                    index = new java.util.Scanner(System.in).nextInt();
                } catch (Exception e) {
                    System.out.println("Geçersiz giriş, tekrar deneyiniz.");
                }
            }

            SavasAraclari secilenKart = kartListesi.get(index - 1);

            // Kullanıcının daha önce seçtiği kartları kontrol ediyoruz
            if (secilmisKartlar.contains(secilenKart) && secilmisKartlar.size() < kartListesi.size()) {
                System.out.println("Bu kartı tekrar seçemezsiniz. Önce diğer kartları seçiniz.");
                return null; // Veya yeniden seçim isteyebilirsiniz
            } else {
                secilmisKartlar.add(secilenKart);

                // Tüm kartlar seçildiyse, seçilmiş kartları sıfırlarız
                if (secilmisKartlar.size() == kartListesi.size()) {
                    secilmisKartlar.clear();
                }

                return secilenKart;
            }
        }
    }
}
