package com.example.demo2;



public class Firkateyn extends DenizAraclari {
    public Firkateyn() {
        super(25); // Dayanıklılık: 25
    }

    @Override
    public String getAltSinif() {
        return "Fırkateyn";
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getHavaVurusAvantaji() {
        return 5;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}

