package com.example.demo2;



public class KFS extends KaraAraclari {
    public KFS() {
        super(10); // Dayanıklılık: 10
    }

    @Override
    public String getAltSinif() {
        return "KFS";
    }

    @Override
    public int getVurus() {
        return 10;
    }

    @Override
    public int getDenizVurusAvantaji() {
        return 10;
    }

    @Override
    public void DurumGuncelle(int hasar) {
        setDayaniklilik(getDayaniklilik() - hasar);
    }
}

