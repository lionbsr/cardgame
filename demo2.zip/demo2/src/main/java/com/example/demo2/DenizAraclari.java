package com.example.demo2;



public abstract class DenizAraclari extends SavasAraclari {
    public DenizAraclari(int dayaniklilik) {
        super(dayaniklilik);
    }

    @Override
    public String getSinif() {
        return "Deniz";
    }

    public abstract String getAltSinif(); // Alt sınıf adı (Fırkateyn, Sida)
    public abstract int getHavaVurusAvantaji(); // Hava saldırısına avantaj
}
