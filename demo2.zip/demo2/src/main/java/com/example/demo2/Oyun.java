package com.example.demo2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.scene.text.*;
import javafx.event.*;
import javafx.scene.Node;

public class Oyun extends Application {
    private int maxHamle;
    private static final int SEVIYE_LIMITI = 20;
    private Oyuncu kullanici;
    private Oyuncu bilgisayar;
    private List<SavasAraclari> kapaliKartlar;
    private List<SavasAraclari> tumKartlar;
    private boolean ilkHamle = true;
    private String logFile = "oyun_log.txt";

    private Stage primaryStage;
    private Scene inputScene;
    private Scene gameScene;
    private int currentHamle;
    private List<SavasAraclari> kullaniciSecimleri = new ArrayList<>();
    private BufferedWriter writer;

    // Bilgisayarın kartlarını göstermek için eklenen bileşenler
    private HBox bilgisayarKartlariBox;
    private Label bilgisayarKartlariLabel;
    private List<Button> bilgisayarKartButonlari = new ArrayList<>(); // Bilgisayarın kart butonları

    // Kullanıcının seçilmiş kartlarını takip eden liste
    private List<SavasAraclari> kullaniciSecilmisKartlar = new ArrayList<>();

    public Oyun() {
        kullanici = new Oyuncu(1, "Kullanıcı", 0);
        bilgisayar = new Oyuncu();

        // Tüm kartlar
        tumKartlar = new ArrayList<>();
        for (int i = 0; i < 6; i++) {
            tumKartlar.add(new Ucak());
            tumKartlar.add(new Obus());
            tumKartlar.add(new Firkateyn());
        }

        // Kapalı kartlar
        kapaliKartlar = new ArrayList<>();
        kapaliKartlar.add(new Siha());
        kapaliKartlar.add(new Sida());
        kapaliKartlar.add(new KFS());
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        createInputScene();
    }

    private void createInputScene() {
        Label hamleLabel = new Label("Lütfen maksimum hamle sayısını giriniz:");
        TextField hamleField = new TextField();
        Label seviyeLabel = new Label("Lütfen kartların başlangıç seviye puanını giriniz (Varsayılan 0'dır):");
        TextField seviyeField = new TextField();

        Button startButton = new Button("Oyunu Başlat");

        startButton.setOnAction(e -> {
            try {
                maxHamle = Integer.parseInt(hamleField.getText());
                int baslangicSeviyePuani = Integer.parseInt(seviyeField.getText());
                setKartSeviyePuani(baslangicSeviyePuani);
                oyunuBaslat();
            } catch (NumberFormatException ex) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Hata");
                alert.setHeaderText("Geçersiz giriş");
                alert.setContentText("Lütfen geçerli sayılar giriniz.");
                alert.showAndWait();
            }
        });

        VBox vbox = new VBox(10);
        vbox.setPadding(new Insets(20));
        vbox.getChildren().addAll(hamleLabel, hamleField, seviyeLabel, seviyeField, startButton);

        inputScene = new Scene(vbox, 400, 300);
        primaryStage.setTitle("Savaş Araçları Kart Oyunu");
        primaryStage.setScene(inputScene);
        primaryStage.show();
    }

    public void oyunuBaslat() {
        try {
            writer = new BufferedWriter(new FileWriter(logFile));
            writer.write("Savaş Araçları Kart Oyunu Başlıyor!\n");
            writer.write("---------------------------------\n");
            kartlariDagit(writer);

            currentHamle = 1;

            createGameScene();

        } catch (IOException e) {
            System.out.println("Log dosyasına yazılamadı: " + e.getMessage());
        }
    }

    private void setKartSeviyePuani(int puan) {
        for (SavasAraclari kart : tumKartlar) {
            kart.setSeviyePuani(puan);
        }
    }

    private void kartlariDagit(BufferedWriter writer) throws IOException {
        List<SavasAraclari> kullaniciKartlari = new ArrayList<>();
        List<SavasAraclari> bilgisayarKartlari = new ArrayList<>();
        Random random = new Random();

        // Kullanıcı ve bilgisayara rastgele kart dağıt
        for (int i = 0; i < 6; i++) {
            kullaniciKartlari.add(tumKartlar.remove(random.nextInt(tumKartlar.size())));
            bilgisayarKartlari.add(tumKartlar.remove(random.nextInt(tumKartlar.size())));
        }

        kullanici.setKartListesi(kullaniciKartlari);
        bilgisayar.setKartListesi(bilgisayarKartlari);

        writer.write("Kullanıcı başlangıç kartları: " + kullaniciKartlari + "\n");
        writer.write("Bilgisayar başlangıç kartları: " + bilgisayarKartlari + "\n");
    }

    private void createGameScene() {
        Label hamleLabel = new Label("--- Hamle " + currentHamle + " ---");

        Label skorLabel = new Label("Kullanıcı Skoru: " + kullanici.getSkor() + " | Bilgisayar Skoru: " + bilgisayar.getSkor());

        TextArea gameLog = new TextArea();
        gameLog.setEditable(false);
        gameLog.setWrapText(true);

        Label kullaniciKartlariLabel = new Label("Kullanıcı Kartları:");
        HBox kullaniciKartlariBox = new HBox(10);
        kullaniciKartlariBox.setPadding(new Insets(10));

        for (SavasAraclari kart : kullanici.getKartListesi()) {
            Button kartButton = new Button(kart.getAltSinif());
            kartButton.setUserData(kart);
            kartButton.setOnAction(e -> {
                selectUserCard(kartButton);
            });
            kullaniciKartlariBox.getChildren().add(kartButton);
        }

        // Bilgisayarın kartlarını göstermek için eklenen kodlar
        bilgisayarKartlariLabel = new Label("Bilgisayarın Kartları:");
        bilgisayarKartlariBox = new HBox(10);
        bilgisayarKartlariBox.setPadding(new Insets(10));

        for (int i = 0; i < bilgisayar.getKartListesi().size(); i++) {
            Button kartButton = new Button("Gizli Kart");
            kartButton.setDisable(true); // İşlevsiz buton
            bilgisayarKartlariBox.getChildren().add(kartButton);
            bilgisayarKartButonlari.add(kartButton);
        }

        Button nextHamleButton = new Button("Hamleyi Yap");
        nextHamleButton.setOnAction(e -> {
            processHamle(gameLog, hamleLabel, skorLabel);
        });

        VBox gameLayout = new VBox(10);
        gameLayout.setPadding(new Insets(10));
        gameLayout.getChildren().addAll(hamleLabel, skorLabel, gameLog, kullaniciKartlariLabel, kullaniciKartlariBox, bilgisayarKartlariLabel, bilgisayarKartlariBox, nextHamleButton);

        gameScene = new Scene(gameLayout, 800, 600);
        primaryStage.setScene(gameScene);
    }

    private void selectUserCard(Button kartButton) {
        SavasAraclari selectedKart = (SavasAraclari) kartButton.getUserData();

        // Eğer kart daha önce seçilmişse ve tüm kartlar seçilmediyse, seçim yapma
        if (kullaniciSecilmisKartlar.contains(selectedKart) && kullaniciSecilmisKartlar.size() < kullanici.getKartListesi().size()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Seçim Hatası");
            alert.setHeaderText("Bu kartı tekrar seçemezsiniz. Önce diğer kartları seçiniz.");
            alert.showAndWait();
            return;
        }

        if (kullaniciSecimleri.contains(selectedKart)) {
            kullaniciSecimleri.remove(selectedKart);
            kartButton.setStyle("");
            kullaniciSecilmisKartlar.remove(selectedKart);
        } else {
            if (kullaniciSecimleri.size() < 3) {
                kullaniciSecimleri.add(selectedKart);
                kartButton.setStyle("-fx-border-color: red;");
                kullaniciSecilmisKartlar.add(selectedKart);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Seçim Hatası");
                alert.setHeaderText("En fazla 3 kart seçebilirsiniz.");
                alert.showAndWait();
            }
        }

        // Eğer tüm kartlar seçildiyse, seçilmiş kartları sıfırla
        if (kullaniciSecilmisKartlar.size() == kullanici.getKartListesi().size()) {
            kullaniciSecilmisKartlar.clear();
        }
    }

    private void processHamle(TextArea gameLog, Label hamleLabel, Label skorLabel) {
        if (kullaniciSecimleri.size() != 3) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Seçim Hatası");
            alert.setHeaderText("Lütfen 3 kart seçiniz.");
            alert.showAndWait();
            return;
        }

        try {
            writer.write("\n--- Hamle " + currentHamle + " ---\n");
            gameLog.appendText("\n--- Hamle " + currentHamle + " ---\n");

            if (!hamleYap(writer, gameLog)) {
                oyunSonucu(writer, gameLog);
                writer.close();
                return;
            }

            kartlariAcilirYap(writer, gameLog);

            skorLabel.setText("Kullanıcı Skoru: " + kullanici.getSkor() + " | Bilgisayar Skoru: " + bilgisayar.getSkor());

            currentHamle++;
            hamleLabel.setText("--- Hamle " + currentHamle + " ---");

            kullaniciSecimleri.clear();

            HBox kullaniciKartlariBox = (HBox) ((VBox) gameScene.getRoot()).getChildren().get(4);
            for (Node node : kullaniciKartlariBox.getChildren()) {
                if (node instanceof Button) {
                    node.setStyle("");
                }
            }

            // Hamle sonunda seçilmiş kartları sıfırlama
            if (kullaniciSecilmisKartlar.size() == kullanici.getKartListesi().size()) {
                kullaniciSecilmisKartlar.clear();
            }
            if (bilgisayar.getSecilmisKartlar().size() == bilgisayar.getKartListesi().size()) {
                bilgisayar.getSecilmisKartlar().clear();
            }

            if (currentHamle > maxHamle) {
                oyunSonucu(writer, gameLog);
                writer.close();
                return;
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean hamleYap(BufferedWriter writer, TextArea gameLog) throws IOException {
        if (kullanici.getKartListesi().size() < 3 || bilgisayar.getKartListesi().size() < 3) {
            writer.write("Yeterli kart kalmadı. Oyun sona eriyor.\n");
            gameLog.appendText("Yeterli kart kalmadı. Oyun sona eriyor.\n");
            return false;
        }

        List<SavasAraclari> kullaniciSecimleriCopy = new ArrayList<>(kullaniciSecimleri);
        List<SavasAraclari> bilgisayarSecimleri = kartSec(bilgisayar);

        // Bilgisayarın seçtiği kartları görselde güncellemek için eklenen kodlar
        for (int i = 0; i < bilgisayarSecimleri.size(); i++) {
            SavasAraclari kart = bilgisayarSecimleri.get(i);
            int index = bilgisayar.getKartListesi().indexOf(kart);
            if (index != -1) {
                Button kartButton = bilgisayarKartButonlari.get(index);
                kartButton.setText(kart.getAltSinif());
                kartButton.setStyle("-fx-border-color: red;");
            }
        }

        gameLog.appendText("\nBilgisayarın seçtiği kartlar:\n");
        for (int i = 0; i < bilgisayarSecimleri.size(); i++) {
            SavasAraclari kart = bilgisayarSecimleri.get(i);
            gameLog.appendText(String.format("%d. Kart: %-10s | Dayanıklılık: %-2d | Puan: %-2d%n",
                    i + 1, kart.getAltSinif(), kart.getDayaniklilik(), kart.getSeviyePuani()));
        }

        HBox kullaniciKartlariBox = (HBox) ((VBox) gameScene.getRoot()).getChildren().get(4);

        for (int i = 0; i < 3; i++) {
            SavasAraclari kullaniciKart = kullaniciSecimleriCopy.get(i);
            SavasAraclari bilgisayarKart = bilgisayarSecimleri.get(i);

            // Kullanıcı kartının bilgisayar kartına saldırısı
            int kullaniciHasar = hesaplaHasar(kullaniciKart, bilgisayarKart);
            bilgisayarKart.DurumGuncelle(kullaniciHasar);

            // Bilgisayar kartının kullanıcı kartına saldırısı
            int bilgisayarHasar = hesaplaHasar(bilgisayarKart, kullaniciKart);
            kullaniciKart.DurumGuncelle(bilgisayarHasar);

            writer.write(String.format("Kullanıcı %s saldırıyor -> Bilgisayar %s hasar aldı: -%d\n",
                    kullaniciKart.getAltSinif(), bilgisayarKart.getAltSinif(), kullaniciHasar));
            writer.write(String.format("Bilgisayar %s saldırıyor -> Kullanıcı %s hasar aldı: -%d\n",
                    bilgisayarKart.getAltSinif(), kullaniciKart.getAltSinif(), bilgisayarHasar));

            gameLog.appendText(String.format("Kullanıcı %s saldırıyor -> Bilgisayar %s hasar aldı: -%d\n",
                    kullaniciKart.getAltSinif(), bilgisayarKart.getAltSinif(), kullaniciHasar));
            gameLog.appendText(String.format("Bilgisayar %s saldırıyor -> Kullanıcı %s hasar aldı: -%d\n",
                    bilgisayarKart.getAltSinif(), kullaniciKart.getAltSinif(), bilgisayarHasar));

            // Kartların dayanıklılığını kontrol edip elenenleri çıkaralım
            if (kullaniciKart.getDayaniklilik() <= 0) {
                writer.write("Kullanıcının " + kullaniciKart.getAltSinif() + " kartı elendi!\n");
                gameLog.appendText("Kullanıcının " + kullaniciKart.getAltSinif() + " kartı elendi!\n");
                bilgisayar.setSkor(bilgisayar.getSkor() + Math.max(10, kullaniciKart.getSeviyePuani()));

                int index = kullanici.getKartListesi().indexOf(kullaniciKart);

                if (index != -1) {
                    kullaniciKartlariBox.getChildren().remove(index);
                    kullanici.getKartListesi().remove(index);
                }
            }
            if (bilgisayarKart.getDayaniklilik() <= 0) {
                writer.write("Bilgisayarın " + bilgisayarKart.getAltSinif() + " kartı elendi!\n");
                gameLog.appendText("Bilgisayarın " + bilgisayarKart.getAltSinif() + " kartı elendi!\n");
                kullanici.setSkor(kullanici.getSkor() + Math.max(10, bilgisayarKart.getSeviyePuani()));

                int index = bilgisayar.getKartListesi().indexOf(bilgisayarKart);

                if (index != -1) {
                    bilgisayarKartlariBox.getChildren().remove(index);
                    bilgisayarKartButonlari.remove(index);
                    bilgisayar.getKartListesi().remove(index);
                }
            }
        }

        // Bilgisayarın seçmediği kartların butonlarını tekrar gizli hale getirme
        for (Button kartButton : bilgisayarKartButonlari) {
            if (!kartButton.getStyle().contains("-fx-border-color: red;")) {
                kartButton.setText("Gizli Kart");
            }
            kartButton.setStyle("");
        }

        gameLog.appendText("\nHamle Sonu Skorlar:\n");
        gameLog.appendText(String.format("Kullanıcı: %d puan | Bilgisayar: %d puan%n", kullanici.getSkor(), bilgisayar.getSkor()));
        return true;
    }

    private void kartlariAcilirYap(BufferedWriter writer, TextArea gameLog) throws IOException {
        Random random = new Random();
        HBox kullaniciKartlariBox = (HBox) ((VBox) gameScene.getRoot()).getChildren().get(4);

        if (kullanici.getSkor() >= SEVIYE_LIMITI && !kapaliKartlar.isEmpty()) {
            SavasAraclari yeniKart = kapaliKartlar.remove(random.nextInt(kapaliKartlar.size()));
            kullanici.getKartListesi().add(yeniKart);
            writer.write("Kullanıcıya yeni kart açıldı: " + yeniKart.getAltSinif() + "\n");
            gameLog.appendText("Kullanıcıya yeni kart açıldı: " + yeniKart.getAltSinif() + "\n");

            Button kartButton = new Button(yeniKart.getAltSinif());
            kartButton.setUserData(yeniKart);
            kartButton.setOnAction(e -> {
                selectUserCard(kartButton);
            });
            kullaniciKartlariBox.getChildren().add(kartButton);
        }

        if (bilgisayar.getSkor() >= SEVIYE_LIMITI && !kapaliKartlar.isEmpty()) {
            SavasAraclari yeniKart = kapaliKartlar.remove(random.nextInt(kapaliKartlar.size()));
            bilgisayar.getKartListesi().add(yeniKart);
            writer.write("Bilgisayara yeni kart açıldı: " + yeniKart.getAltSinif() + "\n");
            gameLog.appendText("Bilgisayara yeni kart açıldı: " + yeniKart.getAltSinif() + "\n");

            // Bilgisayarın kart kutusuna yeni gizli kartı ekleme
            Button kartButton = new Button("Gizli Kart");
            kartButton.setDisable(true); // İşlevsiz buton
            bilgisayarKartlariBox.getChildren().add(kartButton);
            bilgisayarKartButonlari.add(kartButton);
        }
    }

    private List<SavasAraclari> kartSec(Oyuncu oyuncu) {
        List<SavasAraclari> secimler = new ArrayList<>();
        Random random = new Random();

        // Seçilmemiş kartları bulma
        List<SavasAraclari> secilmemisKartlar = new ArrayList<>(oyuncu.getKartListesi());
        secilmemisKartlar.removeAll(oyuncu.getSecilmisKartlar());

        // Eğer seçilmemiş kart kalmadıysa, seçilmiş kartları sıfırla
        if (secilmemisKartlar.isEmpty()) {
            oyuncu.getSecilmisKartlar().clear();
            secilmemisKartlar = new ArrayList<>(oyuncu.getKartListesi());
        }

        while (secimler.size() < 3) {
            SavasAraclari kartSecimi = secilmemisKartlar.get(random.nextInt(secilmemisKartlar.size()));

            if (!secimler.contains(kartSecimi)) {
                secimler.add(kartSecimi);
            }

            // Seçilen kartları oyuncunun seçilmiş kartlar listesine ekliyoruz
            oyuncu.getSecilmisKartlar().add(kartSecimi);

            // Seçilen kartı seçilmemiş kartlar listesinden kaldırıyoruz
            secilmemisKartlar.remove(kartSecimi);

            // Eğer seçilmemiş kart kalmadıysa ve seçimler tamamlanmadıysa, seçilmiş kartları sıfırla
            if (secilmemisKartlar.isEmpty() && secimler.size() < 3) {
                oyuncu.getSecilmisKartlar().clear();
                secilmemisKartlar = new ArrayList<>(oyuncu.getKartListesi());
                secilmemisKartlar.removeAll(secimler);
            }
        }

        return secimler;
    }

    private int hesaplaHasar(SavasAraclari saldiranKart, SavasAraclari savunanKart) {
        int hasar = saldiranKart.getVurus();

        String saldiranSinif = saldiranKart.getSinif();
        String savunanSinif = savunanKart.getSinif();

        // Saldıran kartın rakip kartın sınıfına karşı avantajı varsa
        if ((saldiranSinif.equals("Hava") && savunanSinif.equals("Kara")) ||
                (saldiranSinif.equals("Kara") && savunanSinif.equals("Deniz")) ||
                (saldiranSinif.equals("Deniz") && savunanSinif.equals("Hava"))) {

            // Saldıran kartın vuruş avantajı değerini al
            int vurusAvantaji = 0;
            if (saldiranSinif.equals("Hava")) {
                vurusAvantaji = ((HavaAraclari) saldiranKart).getKaraVurusAvantaji();
            } else if (saldiranSinif.equals("Kara")) {
                vurusAvantaji = ((KaraAraclari) saldiranKart).getDenizVurusAvantaji();
            } else if (saldiranSinif.equals("Deniz")) {
                vurusAvantaji = ((DenizAraclari) saldiranKart).getHavaVurusAvantaji();
            }

            // Saldırı değerine vuruş avantajını ekle
            hasar += vurusAvantaji;
        }

        return hasar;
    }

    private void oyunSonucu(BufferedWriter writer, TextArea gameLog) throws IOException {
        writer.write("\n--- Oyun Sona Erdi ---\n");
        writer.write("Kullanıcı Skoru: " + kullanici.getSkor() + "\n");
        writer.write("Bilgisayar Skoru: " + bilgisayar.getSkor() + "\n");

        gameLog.appendText("\n--- Oyun Sona Erdi ---\n");
        gameLog.appendText(String.format("Kullanıcı Skoru: %d | Bilgisayar Skoru: %d%n", kullanici.getSkor(), bilgisayar.getSkor()));

        if (kullanici.getSkor() > bilgisayar.getSkor()) {
            writer.write("Kazanan: Kullanıcı\n");
            gameLog.appendText("Kazanan: Kullanıcı\n");
        } else if (bilgisayar.getSkor() > kullanici.getSkor()) {
            writer.write("Kazanan: Bilgisayar\n");
            gameLog.appendText("Kazanan: Bilgisayar\n");
        } else {
            writer.write("Oyun Berabere!\n");
            gameLog.appendText("Oyun Berabere!\n");
        }

        ((Button) ((VBox) gameScene.getRoot()).getChildren().get(((VBox) gameScene.getRoot()).getChildren().size() - 1)).setDisable(true);
    }
}
